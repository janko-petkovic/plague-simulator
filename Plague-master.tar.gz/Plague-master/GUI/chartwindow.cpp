#include "chartwindow.h"
#include "ui_chartwindow.h"
#include "drawchart.cpp"

#include <QtCharts>
#include <vector>

using std::vector;

ChartWindow::ChartWindow(QWidget *parent, vector<vector<double>>& data, int predictionDays) :
    QMainWindow(parent),
    ui(new Ui::ChartWindow)
{
    ui->setupUi(this);

    vector<vector<double>> temp(2);
    temp.push_back(data[4]);
    temp.push_back(data[5]);

    QChart* chart = ScatterChart(temp,predictionDays);

    // Setting up the window layout
    QChartView* chartView = new QChartView(chart);
    QFrame* centralFrame = new QFrame();
    QHBoxLayout* myLayout = new QHBoxLayout;
    myLayout->addWidget(chartView);
    chartView->setRenderHint(QPainter::Antialiasing);
    centralFrame->setLayout(myLayout);
    setCentralWidget(centralFrame);
}

ChartWindow::~ChartWindow()
{
    delete ui;
}
