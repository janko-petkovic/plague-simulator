#include <QtCharts>
#include <vector>
#include <iostream>

using std::vector;


QChart* StackedChart(const vector<vector<double>>& data, const int predictionDays) {

    QStackedBarSeries *series = new QStackedBarSeries();

    QBarSet *infectSet = new QBarSet("Infetti");
    QBarSet *recovSet = new QBarSet("Guariti");
    QBarSet *deadSet = new QBarSet("Deceduti");

    // Constructing sets and series
    for (int i=0; i<predictionDays; i++) {
        *infectSet << data[1][i];
        *deadSet << data[2][i];
        *recovSet << data[3][i];
    }

    series -> append(infectSet);
    series -> append(deadSet);
    series -> append(recovSet);

    // creating the chart, cosmetics and final plotting in second window
    QChart* PAYLOAD = new QChart();
    PAYLOAD -> addSeries(series);
    PAYLOAD -> setTitle("Andamenti infetti/guariti/deceduti");
    PAYLOAD->setAnimationOptions(QChart::SeriesAnimations);

    QStringList categories;
    for (int i=0; i<predictionDays; i++) categories << QString::number(i);

    QBarCategoryAxis *axisX = new QBarCategoryAxis();
    axisX->append(categories);
    PAYLOAD->addAxis(axisX, Qt::AlignBottom);
    series->attachAxis(axisX);

    QValueAxis *axisY = new QValueAxis();
    PAYLOAD->addAxis(axisY, Qt::AlignLeft);
    series->attachAxis(axisY);

    return PAYLOAD;
}


// overload of the function above without explicit prediction days
QChart* StackedChart(const vector<vector<double>>& data) {
    int predictionDays = data.size();
    return StackedChart(data,predictionDays);
}



QChart* ScatterChart(const vector<vector<double>>& data, const int predictionDays) {

    QScatterSeries *deadSeries = new QScatterSeries();
    QScatterSeries *recovSeries = new QScatterSeries();
    std::cout << data[0][0] << std::flush;

    // Constructing sets and series
    for (int i=0; i<predictionDays; i++) {
        deadSeries -> append(i,i);
        recovSeries -> append(i,4);
    }

    // creating the chart, cosmetics and final plotting in second window
    QChart* PAYLOAD = new QChart();
    PAYLOAD -> addSeries(deadSeries);
    PAYLOAD -> addSeries(recovSeries);
    PAYLOAD -> setTitle("Andamento nuove guarigioni/decessi");


    return PAYLOAD;
}


// like before, overload of the function above without explicit prediction days
QChart* ScatterChart(const vector<vector<double>>& data) {
    int predictionDays = data.size();
    return ScatterChart(data,predictionDays);
}
