#include "window.h"
#include "ui_window.h"
#include "chartwindow.h"
#include "../Core/Plague.h"
#include "../Core/Plague.cpp"

#include <string>
#include <QtWidgets>
#include <QtCharts>
#include <cassert>
#include <iostream>


Window::Window(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Window)
{
    ui->setupUi(this);


    _dOI = 2;
    _beta = 0.5;
    _death.peak = 1;
    _death.distrType.assign("Uniform");
    _death.finalProb = 0;

    _recov.peak = 1;
    _recov.distrType.assign("Uniform");
    _recov.finalProb = 1;
    _N0 = 20;
    _predictionDays = 100;
    _predictionType = 0;
}

Window::~Window()
{
    delete ui;
}



// days of illness
void Window::set_dOI(int val) { _dOI = val; }
void Window::set_beta(double val) {_beta = val; }

// death status change
void Window::set_deathDistr(int val) {
    if (val==0) _death.distrType.assign("Gaussian");
    else _death.distrType.assign("Uniform");
}

void Window::set_deathPeak(int val) { _death.peak = val; }


// recovery status change
void Window::set_recovDistr(int val) {
    if (val==0) _death.distrType.assign("Gaussian");
    else _death.distrType.assign("Uniform");
}
void Window::set_recovPeak(int val) { _recov.peak = val; }
void Window::set_recovFinalProb(int val) {
    double temp = 0.001*val;
    _recov.finalProb = temp;
    _death.finalProb = 1-temp;
}

// prediction parameters
void Window::set_N0(int val) { _N0 = val; }
void Window::set_predictionDays(int val) { _predictionDays = val; }
void Window::set_predictionType(int val) { _predictionType = val; }


// click simulate: calling PlagueModel prediction methods and data plotting
void Window::simulate() {
    vector<vector<double>> predictionMatrix;

    // choosing the prediction: deterministic or stochastic
    PlagueModel model(_dOI, _death, _recov, _beta);
    switch(_predictionType) {
        case 0: {
            predictionMatrix = model.DetPredict(_predictionDays,_N0);
            break;
        }
        case 1: {
            // plague model stochastic prediction
            break;
        }
    }

    // constructing the death and recovery increment vectors
    vector<double> deadIncr(_predictionDays);
    deadIncr.push_back(0);

    vector<double> recovIncr(_predictionDays);
    recovIncr.push_back(0);

    for (int i=1; i<_predictionDays; i++) {
        deadIncr.push_back(predictionMatrix[2][i]-predictionMatrix[2][i-1]);
        recovIncr.push_back(predictionMatrix[2][i]-predictionMatrix[2][i-1]);
        std::cout << recovIncr[i] << " " << deadIncr[i];
        std::cout << predictionMatrix[2][i] << " " << predictionMatrix[3][i] << std::endl << std::flush;
    }


    // adding the two vectors to the main prediction matrix and graphing in new window
    predictionMatrix.push_back(deadIncr);
    predictionMatrix.push_back(recovIncr);

    _chartW = new ChartWindow(this, predictionMatrix,_predictionDays);
    _chartW->show();


//    for (int k=0; k<_predictionDays; k++) std::cout << predictionMatrix[1][k] << "\t";
//    std::cout << std::flush;
//    std::cout << _dOI << std::endl;
//    std::cout << _beta << std::endl;
//    std::cout << _death.peak << std::endl;
//    std::cout << _death.distrType << std::endl;
//    std::cout << _death.finalProb << std::endl;
//    std::cout << _recov.peak << std::endl;
//    std::cout << _recov.distrType << std::endl;
//    std::cout << _recov.finalProb << std::endl;
//    std::cout << _N0 << std::endl;
//    std::cout << _predictionDays << std::endl;
//    std::cout << _predictionType << std::endl << std::endl << std::flush;
}
