/********************************************************************************
** Form generated from reading UI file 'window.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WINDOW_H
#define UI_WINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "qsliderfromzero.h"
#include "scaledvaluelabel.h"

QT_BEGIN_NAMESPACE

class Ui_Window
{
public:
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QLabel *title;
    QLabel *subtitle;
    QSpacerItem *verticalSpacer_6;
    QFormLayout *formLayout;
    QLabel *lab_dOI;
    QSpinBox *in_dOI;
    QSpacerItem *verticalSpacer;
    QLabel *lab_title_recov;
    QLabel *lab_recovDistr;
    QHBoxLayout *hor_recovDistr;
    QComboBox *combo_recovDistr;
    QSpacerItem *horizontalSpacer;
    QLabel *lab_recovPeak;
    QHBoxLayout *hor_recovPeak;
    QLabel *lab_min_recovPeak;
    QSpacerItem *horizontalSpacer_2;
    QSliderFromZero *slid_recovPeak;
    QSpacerItem *horizontalSpacer_6;
    ScaledValueLabel *lab_max_recovPeak;
    QFrame *frame;
    QLabel *lab_in_recovPeak;
    QLabel *lab_recovFinal;
    QHBoxLayout *hor_recovScale;
    QLabel *lab_min_recovFinal;
    QSpacerItem *horizontalSpacer_4;
    QSlider *in_recovFinal;
    QSpacerItem *horizontalSpacer_7;
    QLabel *lab_max_recovFinal;
    QFrame *frame_2;
    ScaledValueLabel *lab_in_recovFinal;
    QSpacerItem *verticalSpacer_2;
    QLabel *lab_title_death;
    QLabel *lab_deathDistr;
    QHBoxLayout *horizontalLayout_3;
    QComboBox *combo_deathDistr;
    QSpacerItem *horizontalSpacer_3;
    QLabel *lab_deathPeak;
    QHBoxLayout *hor_deathPeak;
    QLabel *la_min_deathPeak;
    QSpacerItem *horizontalSpacer_5;
    QSliderFromZero *slid_deathPeak;
    QSpacerItem *horizontalSpacer_8;
    ScaledValueLabel *lab_max_deathPeak;
    QFrame *frame_3;
    QLabel *label;
    QLabel *lab_deathFinal;
    QLabel *label_3;
    QSpacerItem *verticalSpacer_5;
    QLabel *lab_title_prediction;
    QLabel *lab_N0;
    QSpinBox *in_N0;
    QLabel *lab_predictionDays;
    QSpinBox *in_predictionDays;
    QLabel *lab_predictionType;
    QComboBox *in_predictionType;
    QLabel *lab_beta;
    QDoubleSpinBox *in_beta;
    QPushButton *but_simulate;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Window)
    {
        if (Window->objectName().isEmpty())
            Window->setObjectName(QString::fromUtf8("Window"));
        Window->resize(567, 814);
        centralwidget = new QWidget(Window);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        horizontalLayout = new QHBoxLayout(centralwidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(20, 20, 20, 20);
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        title = new QLabel(centralwidget);
        title->setObjectName(QString::fromUtf8("title"));
        QFont font;
        font.setPointSize(15);
        font.setBold(true);
        font.setWeight(75);
        title->setFont(font);
        title->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(title);

        subtitle = new QLabel(centralwidget);
        subtitle->setObjectName(QString::fromUtf8("subtitle"));
        subtitle->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(subtitle);

        verticalSpacer_6 = new QSpacerItem(20, 60, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout->addItem(verticalSpacer_6);

        formLayout = new QFormLayout();
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setHorizontalSpacing(30);
        formLayout->setVerticalSpacing(12);
        lab_dOI = new QLabel(centralwidget);
        lab_dOI->setObjectName(QString::fromUtf8("lab_dOI"));

        formLayout->setWidget(0, QFormLayout::LabelRole, lab_dOI);

        in_dOI = new QSpinBox(centralwidget);
        in_dOI->setObjectName(QString::fromUtf8("in_dOI"));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(in_dOI->sizePolicy().hasHeightForWidth());
        in_dOI->setSizePolicy(sizePolicy);
        in_dOI->setBaseSize(QSize(0, 0));
        in_dOI->setMinimum(2);
        in_dOI->setMaximum(9999);

        formLayout->setWidget(0, QFormLayout::FieldRole, in_dOI);

        verticalSpacer = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Expanding);

        formLayout->setItem(2, QFormLayout::LabelRole, verticalSpacer);

        lab_title_recov = new QLabel(centralwidget);
        lab_title_recov->setObjectName(QString::fromUtf8("lab_title_recov"));
        QFont font1;
        font1.setBold(true);
        font1.setWeight(75);
        lab_title_recov->setFont(font1);

        formLayout->setWidget(3, QFormLayout::LabelRole, lab_title_recov);

        lab_recovDistr = new QLabel(centralwidget);
        lab_recovDistr->setObjectName(QString::fromUtf8("lab_recovDistr"));

        formLayout->setWidget(4, QFormLayout::LabelRole, lab_recovDistr);

        hor_recovDistr = new QHBoxLayout();
        hor_recovDistr->setObjectName(QString::fromUtf8("hor_recovDistr"));
        combo_recovDistr = new QComboBox(centralwidget);
        combo_recovDistr->addItem(QString());
        combo_recovDistr->addItem(QString());
        combo_recovDistr->setObjectName(QString::fromUtf8("combo_recovDistr"));
        combo_recovDistr->setMaximumSize(QSize(150, 16777215));
        combo_recovDistr->setLayoutDirection(Qt::LeftToRight);

        hor_recovDistr->addWidget(combo_recovDistr);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hor_recovDistr->addItem(horizontalSpacer);


        formLayout->setLayout(4, QFormLayout::FieldRole, hor_recovDistr);

        lab_recovPeak = new QLabel(centralwidget);
        lab_recovPeak->setObjectName(QString::fromUtf8("lab_recovPeak"));

        formLayout->setWidget(5, QFormLayout::LabelRole, lab_recovPeak);

        hor_recovPeak = new QHBoxLayout();
        hor_recovPeak->setObjectName(QString::fromUtf8("hor_recovPeak"));
        lab_min_recovPeak = new QLabel(centralwidget);
        lab_min_recovPeak->setObjectName(QString::fromUtf8("lab_min_recovPeak"));

        hor_recovPeak->addWidget(lab_min_recovPeak);

        horizontalSpacer_2 = new QSpacerItem(10, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        hor_recovPeak->addItem(horizontalSpacer_2);

        slid_recovPeak = new QSliderFromZero(centralwidget);
        slid_recovPeak->setObjectName(QString::fromUtf8("slid_recovPeak"));
        slid_recovPeak->setMinimum(1);
        slid_recovPeak->setMaximum(2);
        slid_recovPeak->setValue(1);
        slid_recovPeak->setSliderPosition(1);
        slid_recovPeak->setOrientation(Qt::Horizontal);
        slid_recovPeak->setTickPosition(QSlider::NoTicks);

        hor_recovPeak->addWidget(slid_recovPeak);

        horizontalSpacer_6 = new QSpacerItem(10, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        hor_recovPeak->addItem(horizontalSpacer_6);

        lab_max_recovPeak = new ScaledValueLabel(centralwidget);
        lab_max_recovPeak->setObjectName(QString::fromUtf8("lab_max_recovPeak"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(lab_max_recovPeak->sizePolicy().hasHeightForWidth());
        lab_max_recovPeak->setSizePolicy(sizePolicy1);
        lab_max_recovPeak->setMinimumSize(QSize(50, 0));
        lab_max_recovPeak->setScaledContents(false);

        hor_recovPeak->addWidget(lab_max_recovPeak);

        frame = new QFrame(centralwidget);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setMinimumSize(QSize(60, 0));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        lab_in_recovPeak = new QLabel(frame);
        lab_in_recovPeak->setObjectName(QString::fromUtf8("lab_in_recovPeak"));
        lab_in_recovPeak->setGeometry(QRect(10, 0, 50, 17));
        QSizePolicy sizePolicy2(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(lab_in_recovPeak->sizePolicy().hasHeightForWidth());
        lab_in_recovPeak->setSizePolicy(sizePolicy2);

        hor_recovPeak->addWidget(frame);


        formLayout->setLayout(5, QFormLayout::FieldRole, hor_recovPeak);

        lab_recovFinal = new QLabel(centralwidget);
        lab_recovFinal->setObjectName(QString::fromUtf8("lab_recovFinal"));

        formLayout->setWidget(6, QFormLayout::LabelRole, lab_recovFinal);

        hor_recovScale = new QHBoxLayout();
        hor_recovScale->setObjectName(QString::fromUtf8("hor_recovScale"));
        lab_min_recovFinal = new QLabel(centralwidget);
        lab_min_recovFinal->setObjectName(QString::fromUtf8("lab_min_recovFinal"));
        QSizePolicy sizePolicy3(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(lab_min_recovFinal->sizePolicy().hasHeightForWidth());
        lab_min_recovFinal->setSizePolicy(sizePolicy3);

        hor_recovScale->addWidget(lab_min_recovFinal);

        horizontalSpacer_4 = new QSpacerItem(10, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        hor_recovScale->addItem(horizontalSpacer_4);

        in_recovFinal = new QSlider(centralwidget);
        in_recovFinal->setObjectName(QString::fromUtf8("in_recovFinal"));
        in_recovFinal->setMaximumSize(QSize(16777215, 16777215));
        in_recovFinal->setMaximum(1000);
        in_recovFinal->setValue(1000);
        in_recovFinal->setOrientation(Qt::Horizontal);

        hor_recovScale->addWidget(in_recovFinal);

        horizontalSpacer_7 = new QSpacerItem(10, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        hor_recovScale->addItem(horizontalSpacer_7);

        lab_max_recovFinal = new QLabel(centralwidget);
        lab_max_recovFinal->setObjectName(QString::fromUtf8("lab_max_recovFinal"));
        sizePolicy3.setHeightForWidth(lab_max_recovFinal->sizePolicy().hasHeightForWidth());
        lab_max_recovFinal->setSizePolicy(sizePolicy3);
        lab_max_recovFinal->setMinimumSize(QSize(50, 0));

        hor_recovScale->addWidget(lab_max_recovFinal);

        frame_2 = new QFrame(centralwidget);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setMinimumSize(QSize(60, 0));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        lab_in_recovFinal = new ScaledValueLabel(frame_2);
        lab_in_recovFinal->setObjectName(QString::fromUtf8("lab_in_recovFinal"));
        lab_in_recovFinal->setGeometry(QRect(10, 0, 67, 17));

        hor_recovScale->addWidget(frame_2);


        formLayout->setLayout(6, QFormLayout::FieldRole, hor_recovScale);

        verticalSpacer_2 = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Expanding);

        formLayout->setItem(7, QFormLayout::LabelRole, verticalSpacer_2);

        lab_title_death = new QLabel(centralwidget);
        lab_title_death->setObjectName(QString::fromUtf8("lab_title_death"));
        lab_title_death->setFont(font1);

        formLayout->setWidget(8, QFormLayout::LabelRole, lab_title_death);

        lab_deathDistr = new QLabel(centralwidget);
        lab_deathDistr->setObjectName(QString::fromUtf8("lab_deathDistr"));

        formLayout->setWidget(9, QFormLayout::LabelRole, lab_deathDistr);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        combo_deathDistr = new QComboBox(centralwidget);
        combo_deathDistr->addItem(QString());
        combo_deathDistr->addItem(QString());
        combo_deathDistr->setObjectName(QString::fromUtf8("combo_deathDistr"));

        horizontalLayout_3->addWidget(combo_deathDistr);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_3);


        formLayout->setLayout(9, QFormLayout::FieldRole, horizontalLayout_3);

        lab_deathPeak = new QLabel(centralwidget);
        lab_deathPeak->setObjectName(QString::fromUtf8("lab_deathPeak"));

        formLayout->setWidget(10, QFormLayout::LabelRole, lab_deathPeak);

        hor_deathPeak = new QHBoxLayout();
        hor_deathPeak->setObjectName(QString::fromUtf8("hor_deathPeak"));
        la_min_deathPeak = new QLabel(centralwidget);
        la_min_deathPeak->setObjectName(QString::fromUtf8("la_min_deathPeak"));

        hor_deathPeak->addWidget(la_min_deathPeak);

        horizontalSpacer_5 = new QSpacerItem(10, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        hor_deathPeak->addItem(horizontalSpacer_5);

        slid_deathPeak = new QSliderFromZero(centralwidget);
        slid_deathPeak->setObjectName(QString::fromUtf8("slid_deathPeak"));
        slid_deathPeak->setMaximum(2);
        slid_deathPeak->setValue(0);
        slid_deathPeak->setSliderPosition(0);
        slid_deathPeak->setOrientation(Qt::Horizontal);
        slid_deathPeak->setTickPosition(QSlider::NoTicks);

        hor_deathPeak->addWidget(slid_deathPeak);

        horizontalSpacer_8 = new QSpacerItem(10, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

        hor_deathPeak->addItem(horizontalSpacer_8);

        lab_max_deathPeak = new ScaledValueLabel(centralwidget);
        lab_max_deathPeak->setObjectName(QString::fromUtf8("lab_max_deathPeak"));
        lab_max_deathPeak->setMinimumSize(QSize(50, 0));

        hor_deathPeak->addWidget(lab_max_deathPeak);

        frame_3 = new QFrame(centralwidget);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        frame_3->setMinimumSize(QSize(60, 0));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        label = new QLabel(frame_3);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 0, 67, 17));

        hor_deathPeak->addWidget(frame_3);


        formLayout->setLayout(10, QFormLayout::FieldRole, hor_deathPeak);

        lab_deathFinal = new QLabel(centralwidget);
        lab_deathFinal->setObjectName(QString::fromUtf8("lab_deathFinal"));

        formLayout->setWidget(11, QFormLayout::LabelRole, lab_deathFinal);

        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        formLayout->setWidget(11, QFormLayout::FieldRole, label_3);

        verticalSpacer_5 = new QSpacerItem(100, 20, QSizePolicy::Minimum, QSizePolicy::Fixed);

        formLayout->setItem(12, QFormLayout::LabelRole, verticalSpacer_5);

        lab_title_prediction = new QLabel(centralwidget);
        lab_title_prediction->setObjectName(QString::fromUtf8("lab_title_prediction"));
        lab_title_prediction->setFont(font1);
        lab_title_prediction->setAlignment(Qt::AlignBottom|Qt::AlignLeading|Qt::AlignLeft);

        formLayout->setWidget(13, QFormLayout::LabelRole, lab_title_prediction);

        lab_N0 = new QLabel(centralwidget);
        lab_N0->setObjectName(QString::fromUtf8("lab_N0"));

        formLayout->setWidget(14, QFormLayout::LabelRole, lab_N0);

        in_N0 = new QSpinBox(centralwidget);
        in_N0->setObjectName(QString::fromUtf8("in_N0"));
        sizePolicy.setHeightForWidth(in_N0->sizePolicy().hasHeightForWidth());
        in_N0->setSizePolicy(sizePolicy);
        in_N0->setMaximum(9999);
        in_N0->setValue(100);

        formLayout->setWidget(14, QFormLayout::FieldRole, in_N0);

        lab_predictionDays = new QLabel(centralwidget);
        lab_predictionDays->setObjectName(QString::fromUtf8("lab_predictionDays"));

        formLayout->setWidget(15, QFormLayout::LabelRole, lab_predictionDays);

        in_predictionDays = new QSpinBox(centralwidget);
        in_predictionDays->setObjectName(QString::fromUtf8("in_predictionDays"));
        sizePolicy.setHeightForWidth(in_predictionDays->sizePolicy().hasHeightForWidth());
        in_predictionDays->setSizePolicy(sizePolicy);
        in_predictionDays->setMinimum(10);
        in_predictionDays->setMaximum(200);
        in_predictionDays->setValue(10);

        formLayout->setWidget(15, QFormLayout::FieldRole, in_predictionDays);

        lab_predictionType = new QLabel(centralwidget);
        lab_predictionType->setObjectName(QString::fromUtf8("lab_predictionType"));

        formLayout->setWidget(16, QFormLayout::LabelRole, lab_predictionType);

        in_predictionType = new QComboBox(centralwidget);
        in_predictionType->addItem(QString());
        in_predictionType->addItem(QString());
        in_predictionType->setObjectName(QString::fromUtf8("in_predictionType"));
        sizePolicy.setHeightForWidth(in_predictionType->sizePolicy().hasHeightForWidth());
        in_predictionType->setSizePolicy(sizePolicy);

        formLayout->setWidget(16, QFormLayout::FieldRole, in_predictionType);

        lab_beta = new QLabel(centralwidget);
        lab_beta->setObjectName(QString::fromUtf8("lab_beta"));

        formLayout->setWidget(1, QFormLayout::LabelRole, lab_beta);

        in_beta = new QDoubleSpinBox(centralwidget);
        in_beta->setObjectName(QString::fromUtf8("in_beta"));
        sizePolicy.setHeightForWidth(in_beta->sizePolicy().hasHeightForWidth());
        in_beta->setSizePolicy(sizePolicy);
        in_beta->setValue(0.500000000000000);

        formLayout->setWidget(1, QFormLayout::FieldRole, in_beta);


        verticalLayout->addLayout(formLayout);

        but_simulate = new QPushButton(centralwidget);
        but_simulate->setObjectName(QString::fromUtf8("but_simulate"));
        QSizePolicy sizePolicy4(QSizePolicy::Expanding, QSizePolicy::Minimum);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(but_simulate->sizePolicy().hasHeightForWidth());
        but_simulate->setSizePolicy(sizePolicy4);
        but_simulate->setMinimumSize(QSize(0, 40));
        but_simulate->setMaximumSize(QSize(16777215, 16777215));
        QFont font2;
        font2.setPointSize(11);
        font2.setBold(false);
        font2.setWeight(50);
        but_simulate->setFont(font2);

        verticalLayout->addWidget(but_simulate);


        horizontalLayout->addLayout(verticalLayout);

        Window->setCentralWidget(centralwidget);
        menubar = new QMenuBar(Window);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 567, 21));
        Window->setMenuBar(menubar);
        statusbar = new QStatusBar(Window);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        Window->setStatusBar(statusbar);

        retranslateUi(Window);
        QObject::connect(in_dOI, SIGNAL(valueChanged(int)), slid_recovPeak, SLOT(setMaximum(int)));
        QObject::connect(slid_recovPeak, SIGNAL(valueChanged(int)), lab_in_recovPeak, SLOT(setNum(int)));
        QObject::connect(in_recovFinal, SIGNAL(valueChanged(int)), lab_in_recovFinal, SLOT(setScaledValue0001(int)));
        QObject::connect(slid_deathPeak, SIGNAL(valueChanged(int)), label, SLOT(setNum(int)));
        QObject::connect(in_dOI, SIGNAL(valueChanged(int)), Window, SLOT(set_dOI(int)));
        QObject::connect(in_beta, SIGNAL(valueChanged(double)), Window, SLOT(set_beta(double)));
        QObject::connect(combo_recovDistr, SIGNAL(currentIndexChanged(int)), Window, SLOT(set_recovDistr(int)));
        QObject::connect(slid_recovPeak, SIGNAL(valueChanged(int)), Window, SLOT(set_recovPeak(int)));
        QObject::connect(in_recovFinal, SIGNAL(valueChanged(int)), Window, SLOT(set_recovFinalProb(int)));
        QObject::connect(combo_deathDistr, SIGNAL(currentIndexChanged(int)), Window, SLOT(set_deathDistr(int)));
        QObject::connect(slid_deathPeak, SIGNAL(valueChanged(int)), Window, SLOT(set_deathPeak(int)));
        QObject::connect(in_N0, SIGNAL(valueChanged(int)), Window, SLOT(set_N0(int)));
        QObject::connect(in_predictionDays, SIGNAL(valueChanged(int)), Window, SLOT(set_predictionDays(int)));
        QObject::connect(in_predictionType, SIGNAL(currentIndexChanged(int)), Window, SLOT(set_predictionType(int)));
        QObject::connect(but_simulate, SIGNAL(clicked()), Window, SLOT(simulate()));
        QObject::connect(in_dOI, SIGNAL(valueChanged(int)), slid_deathPeak, SLOT(setMaximum(int)));
        QObject::connect(in_dOI, SIGNAL(valueChanged(int)), lab_max_recovPeak, SLOT(setValueMinus1(int)));
        QObject::connect(in_dOI, SIGNAL(valueChanged(int)), lab_max_deathPeak, SLOT(setValueMinus1(int)));

        QMetaObject::connectSlotsByName(Window);
    } // setupUi

    void retranslateUi(QMainWindow *Window)
    {
        Window->setWindowTitle(QCoreApplication::translate("Window", "Window", nullptr));
        title->setText(QCoreApplication::translate("Window", "Toy model epidemiologico", nullptr));
        subtitle->setText(QCoreApplication::translate("Window", "Primo ordine perturbativo nel limite S \342\206\222 \342\210\236", nullptr));
        lab_dOI->setText(QCoreApplication::translate("Window", "Durata massima di malattia (giorni)", nullptr));
        lab_title_recov->setText(QCoreApplication::translate("Window", "GUARIGIONE", nullptr));
        lab_recovDistr->setText(QCoreApplication::translate("Window", "Distribuzione  del processo", nullptr));
        combo_recovDistr->setItemText(0, QCoreApplication::translate("Window", "Gaussian", nullptr));
        combo_recovDistr->setItemText(1, QCoreApplication::translate("Window", "Uniform", nullptr));

#if QT_CONFIG(statustip)
        combo_recovDistr->setStatusTip(QString());
#endif // QT_CONFIG(statustip)
#if QT_CONFIG(accessibility)
        combo_recovDistr->setAccessibleName(QString());
#endif // QT_CONFIG(accessibility)
        combo_recovDistr->setCurrentText(QCoreApplication::translate("Window", "Gaussian", nullptr));
        lab_recovPeak->setText(QCoreApplication::translate("Window", "Picco della distribuzione (giorno)", nullptr));
        lab_min_recovPeak->setText(QCoreApplication::translate("Window", "1", nullptr));
        lab_max_recovPeak->setText(QCoreApplication::translate("Window", "1", nullptr));
        lab_in_recovPeak->setText(QCoreApplication::translate("Window", "0", nullptr));
        lab_recovFinal->setText(QCoreApplication::translate("Window", "Probabilita finale di guarigione G", nullptr));
        lab_min_recovFinal->setText(QCoreApplication::translate("Window", "0", nullptr));
        lab_max_recovFinal->setText(QCoreApplication::translate("Window", "1", nullptr));
        lab_in_recovFinal->setText(QCoreApplication::translate("Window", "0", nullptr));
        lab_title_death->setText(QCoreApplication::translate("Window", "DECESSO", nullptr));
        lab_deathDistr->setText(QCoreApplication::translate("Window", "Distribuzione del processo", nullptr));
        combo_deathDistr->setItemText(0, QCoreApplication::translate("Window", "Gaussian", nullptr));
        combo_deathDistr->setItemText(1, QCoreApplication::translate("Window", "Uniform", nullptr));

        lab_deathPeak->setText(QCoreApplication::translate("Window", "Picco della distribuzione (giorno)", nullptr));
        la_min_deathPeak->setText(QCoreApplication::translate("Window", "1", nullptr));
        lab_max_deathPeak->setText(QCoreApplication::translate("Window", "1", nullptr));
        label->setText(QCoreApplication::translate("Window", "0", nullptr));
        lab_deathFinal->setText(QCoreApplication::translate("Window", "Probabilita' finale di decesso", nullptr));
        label_3->setText(QCoreApplication::translate("Window", "1 - G", nullptr));
        lab_title_prediction->setText(QCoreApplication::translate("Window", "SIMULAZIONE", nullptr));
        lab_N0->setText(QCoreApplication::translate("Window", "Numero iniziale di contagiati", nullptr));
        lab_predictionDays->setText(QCoreApplication::translate("Window", "Durata della previsione (giorni)", nullptr));
        lab_predictionType->setText(QCoreApplication::translate("Window", "Tipo di previsione", nullptr));
        in_predictionType->setItemText(0, QCoreApplication::translate("Window", "Deterministica", nullptr));
        in_predictionType->setItemText(1, QCoreApplication::translate("Window", "Stocastica", nullptr));

        lab_beta->setText(QCoreApplication::translate("Window", "Tasso di contagio giornaliero Beta", nullptr));
        but_simulate->setText(QCoreApplication::translate("Window", "RUN", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Window: public Ui_Window {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WINDOW_H
